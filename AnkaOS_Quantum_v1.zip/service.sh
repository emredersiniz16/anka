#!/system/bin/sh
MODDIR=${0%/*}
sleep 10
export LD_LIBRARY_PATH=$MODDIR/system/lib:$LD_LIBRARY_PATH
export ANKA_CORE_PATH=$MODDIR/system/anka_core
$MODDIR/system/bin/anka_os_bin &
